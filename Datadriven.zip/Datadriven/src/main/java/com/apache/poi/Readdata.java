package com.apache.poi;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

public class Readdata {

	// for 97 - 2003 .xls format need to use HSSF, HSSF workbook//
	// for 2007 or later .xlsx format need to use XSSF, XSSF workbook//

	List<String> username = new ArrayList<String>();
	List<String> password = new ArrayList<String>();

	public void getxlData() throws IOException {

		try {
			FileInputStream file = new FileInputStream("howtodoinjava_demo.xls");

			// Create Workbook instance holding reference to .xlsx file
			HSSFWorkbook workbook = new HSSFWorkbook(file);

			// Get first/desired sheet from the workbook
			Sheet sheet = workbook.getSheetAt(0);

			// Iterate through each rows one by one
			Iterator<Row> rowIterator = sheet.iterator();
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				// For each row, iterate through all the columns
				Iterator<Cell> cellIterator = row.cellIterator();
				int i = 2;
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					if (i % 2 == 0) {
						username.add(cell.toString());
					} else {
						password.add(cell.getStringCellValue());
					}
					i++;
				}

			}
			file.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws IOException {

		Readdata read = new Readdata();
		read.getxlData();

	}

}
