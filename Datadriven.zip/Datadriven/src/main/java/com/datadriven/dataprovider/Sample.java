package com.datadriven.dataprovider;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Sample {

	//for jxl need to use 97 - 2003 format only//
	@Test(dataProvider="login")
	public void loginpage(String username, String password) {

		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://newtours.demoaut.com/mercurysignon.php");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.name("userName")).sendKeys(username);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("login")).click();

		driver.close();
	}
	
	public String[][] getData() throws BiffException, IOException{
		FileInputStream excel = new FileInputStream("D:\\Users\\342685\\Desktop\\Project\\testdata.xls");
		Workbook workbook = Workbook.getWorkbook(excel);
		Sheet sheet = workbook.getSheet(0);
		int rowcount = sheet.getRows();
		int columncount = sheet.getColumns();
		
		String testdata [][] = new String[rowcount-1][columncount];
		
		for(int i=1;i<rowcount;i++){
			for(int j=0;j<columncount;j++){
				testdata [i-1][j] = sheet.getCell(j, i).getContents();
			}
		}
		return testdata;
	}
	
	@DataProvider(name="login")
	public String[][] dataProvider() throws BiffException, IOException{
		data= getData();
		return data;
	}
	
	String [][] data;
}
